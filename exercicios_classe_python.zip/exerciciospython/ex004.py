class Retangulo:

    def __init__(self, largura, altura):
        self.largura = largura
        self.altura = altura

    def calcular_area(self):
        return self.largura * self.altura

    def calcular_perimetro(self):
        return (self.largura + self.altura) * 2


r1 = Retangulo(10, 2)
print(f'Área: {r1.calcular_area()}')
print(f'Perímetro: {r1.calcular_perimetro()}')
