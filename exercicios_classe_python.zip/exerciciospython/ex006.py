class Produto:

    def __init__(self, nome, preco, estoque):
        self.nome = nome
        self.preco = preco
        self.estoque = estoque

    def aplicar_desconto(self, porcent):
        return self.preco - (self.preco / 100 * porcent)


p1 = Produto('Notebook Gamer', 5000, 10)
p1_desconto = p1.aplicar_desconto(15)

print(f'\nPreço original: R${p1.preco:.2f}')
print(f'Preço com desconto: R${p1_desconto:.2f}')
