class Aluno:

    def __init__(self, nome):
        self.nome = nome
        self.notas = []

    def adicionar_nota(self):
        self.notas.append(float(input(f'Digite a nota que deseja adicionar de {self.nome}: ')))

    def calcular_media(self):
        media = 0
        if not self.notas:
            return media
        return sum(self.notas) / len(self.notas)


a1 = Aluno('Gustavo')
a1.adicionar_nota()
a1.adicionar_nota()
a1.adicionar_nota()
a1.adicionar_nota()

a1_media = a1.calcular_media()
print(f'\nAluno: {a1.nome}\nMédia: {a1_media:.1f}')
