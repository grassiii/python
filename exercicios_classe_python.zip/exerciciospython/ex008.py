class Animal:

    def __init__(self, nome):
        self.nome = nome

    def falar(self):
        return 'Som genérico...'


class Cachorro(Animal):

    def falar(self):
        return 'Au au...'


a1 = Animal('Criatura')
c1 = Cachorro('Rex')

print(f'{a1.nome} fala {a1.falar()}')
print(f'{c1.nome} fala {c1.falar()}')
