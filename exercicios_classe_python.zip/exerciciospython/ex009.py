class Funcionario:

    def __init__(self, nome, salario):
        self.nome = nome
        self.salario = salario


class Gerente(Funcionario):

    def __init__(self, nome, salario, bonus):
        super().__init__(nome, salario)
        self.bonus = bonus

    def salario_atual(self):
        return self.salario + self.bonus


g1 = Gerente('Maria', 6000, 1500)
print(f'O salário de {g1.nome} com bonus é de R$ {g1.salario_atual()}')
