class Motor:
    def __init__(self, potencia):
        self.potencia = potencia

    def ligar(self):
        print(f'Motor de {self.potencia}cv ligado...')


class Carro:
    def __init__(self, modelo, motor):
        self.modelo = modelo
        self.motor = motor

    def ligar_carro(self):
        print(f'Ligando o {self.modelo}...')
        self.motor.ligar()


motor_v8 = Motor('450')
mustang = Carro('Mustang GT', motor_v8)
mustang.ligar_carro()
