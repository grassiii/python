class ContaBancaria:
    def __init__(self, saldo=0):
        self.__saldo = saldo

    def depositar(self, valor):
        if valor > 0:
            self.__saldo += valor
            print(f'Depósito realizado com sucesso!')
        else:
            print(f'Valor inválido para depósito, por favor, insira um valor válido.')

    def sacar(self, valor):
        if valor < self.__saldo:
            self.__saldo -= valor
            print(f'Saque realizado com sucesso!')
        else:
            print(f'Valor inválido para saque, por favor, insira um valor válido.')

    def ver_saldo(self):
        print(f'Saldo atual: R$ {self.__saldo:.2f}')


c1 = ContaBancaria()
c1.ver_saldo()
c1.depositar(500)
c1.ver_saldo()
c1.sacar(600)
c1.sacar(150)
c1.ver_saldo()
