class Veiculo:
    def __init__(self, marca, modelo):
        self.marca = marca
        self.modelo = modelo

    def acelerar(self):
        print(f'\nO {self.modelo} está acelerando!')


class Moto(Veiculo):
    def __init__(self, marca, modelo, cilindradas):
        super().__init__(marca, modelo)
        self.cilindradas = cilindradas

    def empinar(self):
        print(f'\nA {self.modelo} está empinando!')

    def mostrar_info(self):
        print(f'\nMoto: {self.marca} {self.modelo}')


m1 = Moto('Yamaha', 'Fazer 250', 500)
m1.mostrar_info()
m1.acelerar()
m1.empinar()
