class Cachorro:

    numero_de_cachorros = 0

    def __init__(self, nome):
        self.nome = nome
        Cachorro.numero_de_cachorros += 1


def numero_cachorros(c):
    print(f'Número de cachorros: {c.numero_de_cachorros}')


c1 = Cachorro('Rex')
numero_cachorros(Cachorro)
c2 = Cachorro('Totó')
numero_cachorros(Cachorro)
