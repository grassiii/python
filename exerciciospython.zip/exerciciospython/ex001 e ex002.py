class Livro:

    def __init__(self, titulo, autor, paginas):
        self.titulo = titulo
        self.autor = autor
        self.paginas = paginas

    def descricao(self):

        print(f'O livro "{self.titulo}", de {self.autor} tem {self.paginas} página(s).')


livro = Livro('Aprendendo Python', 'Alex da Silva', 1)
livro.descricao()
