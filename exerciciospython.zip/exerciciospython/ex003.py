class Circulo:

    def __init__(self, raio):
        self.raio = raio

    def calcular_area(self):
        return self.raio ** 2 * 3.14159


c1 = Circulo(5)
print(f'A área de {c1.raio} é: {c1.calcular_area():.2f}')