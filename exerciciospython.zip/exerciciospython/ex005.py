class ContaBancaria:

    def __init__(self, titular, saldo):
        self.titular = titular
        self.saldo = saldo

    def depositar(self):
        deposito = float(input(f'{self.titular}, digite a quantidade que deseja depositar: R$'))

        self.saldo += deposito

    def sacar(self):
        self.ver_saldo()

        while True:
            saque = float(input('Digite a quantidade que deseja sacar: R$'))
            if saque > self.saldo:
                print('Quantidade inválida, insira outro valor.')
            else:
                self.saldo -= saque
                break

    def ver_saldo(self):
        print(f'\nConta: {self.titular}\nSaldo: R${self.saldo:.2f}')


def menu_bancario():
    while True:
        print('\n[1] Depositar')
        print('[2] Sacar')
        print('[3] Ver saldo')
        print('[4] Sair')
        try:
            opc = int(input('Digite uma opção: '))
            if opc < 1 or opc > 4:
                raise ValueError('Erro: Digite uma opção válida')
            else:
                return opc

        except ValueError:
            print('Erro: Digite uma opção válida')


while True:
    try:
        nome = input('Digite o titular da conta bancária: ')
        sal = float(input(f'Digite o saldo de {nome}: R$'))

        c1 = ContaBancaria(nome, sal)
        break

    except ValueError as e:
        print(f'Erro: {e}')

while True:

    opc1 = menu_bancario()

    match opc1:

        case 1:
            c1.depositar()
        case 2:
            c1.sacar()
        case 3:
            c1.ver_saldo()
        case 4:
            print('Programa encerrado.')
            break
